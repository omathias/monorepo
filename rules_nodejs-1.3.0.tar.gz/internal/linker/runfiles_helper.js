module.exports = require('./index.js').runfiles;
