## structs.to_dict

<pre>
structs.to_dict(<a href="#structs.to_dict-s">s</a>)
</pre>

Converts a `struct` to a `dict`.

### Parameters

<table class="params-table">
  <colgroup>
    <col class="col-param" />
    <col class="col-description" />
  </colgroup>
  <tbody>
    <tr id="structs.to_dict-s">
      <td><code>s</code></td>
      <td>
        required.
        <p>
          A `struct`.
        </p>
      </td>
    </tr>
  </tbody>
</table>


