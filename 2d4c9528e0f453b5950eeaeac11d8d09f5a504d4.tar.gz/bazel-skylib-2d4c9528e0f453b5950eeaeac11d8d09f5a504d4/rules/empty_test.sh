#!/bin/bash
# This is a support file for build_test.bzl, it shouldn't be used by anything else.
exit 0
