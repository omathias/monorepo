This folder contains Bazel configuration artifacts for a debian8 based clang
toolchain.
